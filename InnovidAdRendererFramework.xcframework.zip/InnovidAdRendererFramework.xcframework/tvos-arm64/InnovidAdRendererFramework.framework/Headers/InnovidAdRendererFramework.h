//
//  InnovidAdRendererFramework.h
//  InnovidAdRendererFramework
//
//  Created by Jake Lavenberg on 3/15/23.
//

#import <Foundation/Foundation.h>

//! Project version number for InnovidAdRendererFramework.
FOUNDATION_EXPORT double InnovidAdRendererFrameworkVersionNumber;

//! Project version string for InnovidAdRendererFramework.
FOUNDATION_EXPORT const unsigned char InnovidAdRendererFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InnovidAdRendererFramework/PublicHeader.h>


